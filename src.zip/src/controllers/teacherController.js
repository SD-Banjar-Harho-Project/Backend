import Teacher from "../models/teacher.js";
import { successResponse, errorResponse } from "../utils/responseHelper.js";

export const getAllTeachers = async (req, res, next) => {
  try {
    const teachers = await Teacher.findAll();
    return successResponse(res, "Teachers retrieved successfully", teachers);
  } catch (error) {
    next(error);
  }
};

export const getActiveTeachers = async (req, res, next) => {
  try {
    const teachers = await Teacher.findActive();
    return successResponse(
      res,
      "Active teachers retrieved successfully",
      teachers
    );
  } catch (error) {
    next(error);
  }
};

export const getTeacherById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const teacher = await Teacher.findById(id);

    if (!teacher) {
      return errorResponse(res, "Teacher not found", 404);
    }

    return successResponse(res, "Teacher retrieved successfully", teacher);
  } catch (error) {
    next(error);
  }
};

export const createTeacher = async (req, res, next) => {
  try {
    const data = req.body;

    // Handle photo upload if exists
    if (req.file) {
      data.photo = req.file.path;
    }

    const teacher = await Teacher.create(data);

    return successResponse(res, "Teacher created successfully", teacher, 201);
  } catch (error) {
    next(error);
  }
};

export const updateTeacher = async (req, res, next) => {
  try {
    const { id } = req.params;
    const data = req.body;

    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return errorResponse(res, "Teacher not found", 404);
    }

    // Handle photo upload if exists
    if (req.file) {
      data.photo = req.file.path;
    }

    const updatedTeacher = await Teacher.update(id, data);

    return successResponse(res, "Teacher updated successfully", updatedTeacher);
  } catch (error) {
    next(error);
  }
};

export const deleteTeacher = async (req, res, next) => {
  try {
    const { id } = req.params;

    const teacher = await Teacher.findById(id);
    if (!teacher) {
      return errorResponse(res, "Teacher not found", 404);
    }

    await Teacher.softDelete(id);

    return successResponse(res, "Teacher deleted successfully");
  } catch (error) {
    next(error);
  }
};
